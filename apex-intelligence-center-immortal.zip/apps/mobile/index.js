import 'expo-router/entry';
